/* Dashboard shell: rearranges existing controls without replacing app logic */
(() => {
  "use strict";
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  function init() {
    const wrap = $(".wrap"), header = $(".top"), brand = $(".top .brand");
    if (!wrap || !header || $("#avLeftSidebar")) return;
    const sidebar = document.createElement("aside");
    sidebar.id = "avLeftSidebar";
    sidebar.setAttribute("aria-label", "Navigation principale");
    if (brand) sidebar.append(brand);
    const primary = document.createElement("div");
    primary.className = "av-nav-group";
    primary.innerHTML = '<div class="av-nav-label">Menu</div>';
    const secondary = document.createElement("div");
    secondary.className = "av-nav-group";
    secondary.innerHTML = '<div class="av-nav-label">Bibliothèque</div>';
    const actions = $("#headActions");
    const moveButton = (id, target, label, icon) => {
      const b = $("#"+id);
      if (!b) return;
      b.classList.remove("primary");
      b.setAttribute("aria-label", label);
      b.innerHTML = '<span class="av-side-icon" aria-hidden="true">'+icon+'</span><span class="av-side-text">'+label+'</span>';
      target.append(b);
    };
    moveButton("navLibrary", primary, "Accueil", '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 11 12 4l8 7v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z"/></svg>');
    moveButton("navChat", primary, "Communauté", '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1.1-4.6A8 8 0 1 1 21 12z"/><path d="M9 11h6M9 14h3.5"/></svg>');
    moveButton("navVideos", primary, "Vidéos", '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="4"/><path d="m10.5 9.5 4 2.5-4 2.5z"/></svg>');
    moveButton("navCalendar", primary, "Agenda", '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="5" width="17" height="15" rx="3"/><path d="M8 3v4M16 3v4M3.5 10h17"/></svg>');
    const discover = document.createElement("button");
    discover.type = "button"; discover.className = "btn av-discover";
    discover.innerHTML = '<span class="av-side-icon" aria-hidden="true">'+'<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5z"/></svg>'+'</span><span class="av-side-text">Découvrir</span>';
    discover.addEventListener("click", () => { $("#navLibrary")?.click(); const q=$("#catalogueQuery"); if(q){ q.scrollIntoView({behavior:"smooth",block:"center"}); q.focus({preventScroll:true}); } });
    primary.append(discover);
    const collection = document.createElement("button");
    collection.type = "button";
    collection.className = "btn";
    collection.innerHTML = '<span class="av-side-icon" aria-hidden="true"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h5v14H4zM9 5h5v14H9z"/><path d="m15 6 4-1 2 13-4 1z"/></svg></span><span class="av-side-text">Collection</span>';
    collection.addEventListener("click", () => { $("#navLibrary")?.click(); $("#search")?.focus(); });
    secondary.append(collection);
    const recent = document.createElement("button");
    recent.type = "button";
    recent.className = "btn";
    recent.innerHTML = '<span class="av-side-icon" aria-hidden="true"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></span><span class="av-side-text">Récents</span>';
    recent.addEventListener("click", () => { const section=$("#resumeSection"); if(section){section.style.display="block";section.scrollIntoView({behavior:"smooth",block:"start"});} else $("#navLibrary")?.click(); });
    secondary.append(recent);
    const spacer = document.createElement("div");
    spacer.className = "av-sidebar-spacer";
    const logout = document.createElement("button");
    logout.type = "button";
    logout.className = "btn";
    logout.innerHTML = '<span class="av-side-icon" aria-hidden="true"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="9" r="3.5"/><path d="M5 20a7 7 0 0 1 14 0"/></svg></span><span class="av-side-text">Compte</span>';
    logout.addEventListener("click", () => $("#authOpen")?.click());
    sidebar.append(primary, secondary, spacer, logout);
    wrap.prepend(sidebar);

    const right = document.createElement("aside");
    right.id = "avRightSidebar";
    right.setAttribute("aria-label", "Suggestions d’animes");
    right.innerHTML = '<div class="av-rail-head"><strong>À découvrir</strong><span class="av-rail-label">ANIMEVERSE</span></div><label class="av-rail-search"><input id="avRailSearch" type="search" placeholder="⌕ Rechercher un anime…" aria-label="Rechercher un anime"></label><section class="av-rail-section"><h3>Populaires</h3><div id="avRailPopular"></div><a class="av-rail-more" href="/animes.html">Voir le catalogue</a></section><section class="av-rail-section"><h3>Explorer</h3><div id="avRailMovies"></div><a class="av-rail-more" href="/animes.html">Découvrir plus</a></section>';
    wrap.append(right);
    const makeRailItems=(items,target)=>{const container=$("#"+target);if(!container)return;container.textContent="";items.forEach(m=>{const item=document.createElement("a");item.className="av-rail-item";item.href=m.siteUrl||"#";item.target="_blank";item.rel="noopener";const img=document.createElement("img");img.className="av-rail-poster";img.alt="";img.loading="lazy";img.src=(m.coverImage&&m.coverImage.medium)||"";img.onerror=()=>{img.removeAttribute("src");img.style.background="linear-gradient(145deg,#1d3a5a,#29202f)"};const copy=document.createElement("span");const name=document.createElement("strong");name.textContent=(m.title&&(m.title.english||m.title.romaji))||"Anime";const detail=document.createElement("small");detail.textContent=(m.genres||[]).slice(0,2).join(" · ");const rating=document.createElement("small");rating.className="av-rating";rating.textContent=m.averageScore?"★ "+(m.averageScore/10).toFixed(1):"À explorer";copy.append(name,detail,rating);item.append(img,copy);container.append(item)})};
    fetch("https://graphql.anilist.co",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:'query{a:Page(perPage:3){media(type:ANIME,sort:TRENDING_DESC){title{romaji english}genres averageScore siteUrl coverImage{medium}}}b:Page(perPage:3){media(type:ANIME,format:MOVIE,sort:POPULARITY_DESC){title{romaji english}genres averageScore siteUrl coverImage{medium}}}}'})}).then(r=>r.json()).then(x=>{makeRailItems(x.data.a.media,"avRailPopular");makeRailItems(x.data.b.media,"avRailMovies")}).catch(()=>{});
    const railSearch = $("#avRailSearch");
    railSearch.addEventListener("keydown", event => {
      if (event.key === "Enter" && railSearch.value.trim()) { const q=$("#catalogueQuery"); $("#navLibrary")?.click(); if (q) { q.value=railSearch.value.trim(); q.scrollIntoView({behavior:"smooth",block:"center"}); $("#catalogueForm")?.requestSubmit?.(); } }
    });
    const activeNav = () => {
      const view = ["libraryView","chatView","videosView","calendarView"].find(id => { const e=$("#"+id); return e && !e.classList.contains("hidden"); });
      const map = {libraryView:"navLibrary",chatView:"navChat",videosView:"navVideos",calendarView:"navCalendar"};
      $$("#avLeftSidebar .av-nav-group button").forEach(b => b.removeAttribute("aria-current"));
      if (map[view]) $("#"+map[view])?.setAttribute("aria-current","page");
    };
    document.addEventListener("click", event => {
      if (event.target.closest("#navLibrary,#navChat,#navVideos,#navCalendar")) setTimeout(activeNav, 30);
    });
    const views = ["#libraryView","#chatView","#videosView","#calendarView"].map(s => $(s)).filter(Boolean);
    if (views.length) new MutationObserver(activeNav).observe(wrap,{subtree:true,attributes:true,attributeFilter:["class"]});
    activeNav();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init, {once:true});
  else init();
})();